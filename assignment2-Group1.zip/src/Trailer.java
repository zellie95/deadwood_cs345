import java.util.ArrayList;

public class Trailer extends Room {

	public Trailer(String title, ArrayList<String> adjRooms) {
		super(title,adjRooms);
	}

	// public void initiatePlayerPosition(){	
	// }
}
