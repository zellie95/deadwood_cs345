
public class StarringRole extends Role {
	public StarringRole(int rank) {
		super(rank);
	}
}
