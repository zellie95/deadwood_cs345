
public class ExtraRole extends Role{
	public ExtraRole(int rank) {
		super(rank);
	}
}
